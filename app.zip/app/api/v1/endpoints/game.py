"""
Handles game-related endpoints such as recommending a game.

This will later use the MiniLM-based recommendation engine.
"""